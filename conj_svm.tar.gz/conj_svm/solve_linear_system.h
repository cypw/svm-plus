#ifndef _SOLVE_LINEAR_SYSTEM_H_
#define _SOLVE_LINEAR_SYSTEM_H_

int solve_linear_system(double **a, double *b, int n);

#endif
