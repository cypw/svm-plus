#ifndef _COMMON_H
#define _COMMON_H

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <float.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <sys/param.h>
#include <sys/times.h>

#define LIBSVM_VERSION 289

typedef double Qfloat;
typedef signed char schar;
#ifndef min
template <class T> inline T min(T x,T y) { return (x<y)?x:y; }
#endif
#ifndef max
template <class T> inline T max(T x,T y) { return (x>y)?x:y; }
#endif
template <class T> inline void swap(T& x, T& y) { T t=x; x=y; y=t; }
template <class S, class T> inline void clone(T*& dst, S* src, int n)
{
  dst = new T[n];
  memcpy((void *)dst,(void *)src,sizeof(T)*n);
}
inline double powi(double base, int times)
{
  double tmp = base, ret = 1.0;

  for(int t=times; t>0; t/=2)
    {
      if(t%2==1) ret*=tmp;
      tmp = tmp * tmp;
    }
  return ret;
}
#define INF HUGE_VAL
#define TAU 1e-12
#define Malloc(type,n) (type *)malloc((n)*sizeof(type))

enum { BETA_I_BETA_J, ALPHA_I_ALPHA_J, ALPHA_I_ALPHA_J_BETA_K}; 

static void print_string_stdout(const char *s)
{
  fputs(s,stdout);
  fflush(stdout);
}

static void (*svm_print_string) (const char *) = &print_string_stdout;

static void info(const char *fmt,...)
{
  char buf[BUFSIZ];
  va_list ap;
  va_start(ap,fmt);
  vsprintf(buf,fmt,ap);
  va_end(ap);
  (*svm_print_string)(buf);
}

struct svm_node
{
  int index;
  double value;
};

struct svm_problem
{
  int l;
  double *y;
  struct svm_node **x;
  struct svm_node **x_star;
};

enum { C_SVC, NU_SVC, ONE_CLASS, EPSILON_SVR, NU_SVR, SVM_PLUS };	/* svm_type */
enum { LINEAR, POLY, RBF, SIGMOID, PRECOMPUTED }; /* kernel_type */

struct svm_parameter
{
  int svm_type;
  int kernel_type;
  int kernel_type_star;
  int degree;	/* for poly */
  int degree_star; /* for poly in the correcting space */
  double gamma;	/* for poly/rbf/sigmoid */
  double gamma_star;	/* for poly/rbf/sigmoid in the correcting space */
  double coef0;	/* for poly/sigmoid */
  double coef0_star;	/* for poly/sigmoid in the correcting space */

  /* these are for training only */
  double cache_size; /* in MB */
  double eps;	/* stopping criteria */
  double C;	/* for C_SVC, EPSILON_SVR, NU_SVR and SVM_PLUS */
  double tau;     /* for SVM_PLUS */
  int nr_weight;		/* for C_SVC and SVM_PLUS */
  int *weight_label;	/* for C_SVC and SVM_PLUS */
  double* weight;		/* for C_SVC and SVM_PLUS */
  double nu;	/* for NU_SVC, ONE_CLASS, and NU_SVR */
  double p;	/* for EPSILON_SVR */
  int shrinking;	/* use the shrinking heuristics */
  int probability; /* do probability estimates */
  int optimizer;
};

struct svm_model *svm_train(const struct svm_problem *prob, const struct svm_parameter *param);
void svm_cross_validation(const struct svm_problem *prob, const struct svm_parameter *param, int nr_fold, double *target);

int svm_save_model(const char *model_file_name, const struct svm_model *model);
struct svm_model *svm_load_model(const char *model_file_name);

int svm_get_svm_type(const struct svm_model *model);
int svm_get_nr_class(const struct svm_model *model);
void svm_get_labels(const struct svm_model *model, int *label);
double svm_get_svr_probability(const struct svm_model *model);

void svm_predict_values(const struct svm_model *model, const struct svm_node *x, double* dec_values);
double svm_predict(const struct svm_model *model, const struct svm_node *x);
double svm_predict_probability(const struct svm_model *model, const struct svm_node *x, double* prob_estimates);

void svm_destroy_model(struct svm_model *model);
void svm_destroy_param(struct svm_parameter *param);

const char *svm_check_parameter(const struct svm_problem *prob, const struct svm_parameter *param);
int svm_check_probability_model(const struct svm_model *model);

struct SolutionInfo {
  double obj;
  double rho;
  double rho_star;
  double upper_bound_p;
  double upper_bound_n;
  double upper_bound_p_star;
  double upper_bound_n_star;
  double r;   // for Solver_NU
};


#endif 
